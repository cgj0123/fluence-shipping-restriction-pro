/*! Minimal ChartJS loader placeholder */
